package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Joystick;

/**
 *
 * @author Martin Wickham (MartinWickham@comcast.net)
 */
public class DriveTrain extends Component {
    
    private final Piston leftPiston;
    private boolean desiredShift;
    private final Ultrasonic front;
    private final Motor left, right;
    
    public static final double SAFE_SPEED = 0.8,
                               HI_SCALE = 0.8,
                               LO_SCALE = 0.5;
        
    protected DriveTrain(int leftJagPort, int rightJagPort, int pout, int pin, int ultFrontPort, boolean useCAN) {
        leftPiston = new Piston(pout, pin);
        front = new Ultrasonic(ultFrontPort, ULTRA_SMOOTHING);
        if (useCAN) {
            left = new CANMotor(leftJagPort);
            right = new CANMotor(rightJagPort);
        } else {
            left = new PWMMotor(leftJagPort);
            right = new PWMMotor(rightJagPort);
        }
    }
    
    public void monitor() {
        SimpleLCD.getInstance().monitor(this, DISTANCE_LINE);
    }
    
    public void stopMonitor() {
        SimpleLCD.getInstance().stopMonitor(DISTANCE_LINE);
    }
    
    public String toString() {
        double d = front.getDistance();
        return "d: "+(int)(d/12.)+"' "+CANDebug.round(d%12)+"\"";
    }
    
    public void shift(boolean newShift) {
        desiredShift = newShift;
    }
    
    public void updateShifters() {
        try {
            if((leftPiston.isExtended() != desiredShift) && canShift()) {
                leftPiston.set(desiredShift);
            }
        } catch (Exception ex) {
            DebugManager.getInstance().println(ex);
        }
    }
    
    public boolean getTargetState() {
        return desiredShift;
    }
    public boolean getActualState() {
        return leftPiston.isExtended();
    }
    
    public boolean canShift() {
        return (Math.abs(getRightSpeed()) <= SAFE_SPEED) && (Math.abs(getLeftSpeed()) <= SAFE_SPEED);
    }
    
    public double getLeftSpeed() {
        return left.get();
    }
    public double getRightSpeed() {
        return right.get();
    }
    
    public void setLMotor(double speed) {
        left.set(speed);
    }
    public void setRMotor(double speed) {
        right.set(-speed);
    }
    
    public void update(Joystick leftStick, Joystick rightStick, Joystick manipStick) {
        double rightvalue = rightStick.getY();
        double leftvalue = leftStick.getY();
//        if(getActualState()) {
//            if (!leftStick.getRawButton(ALT_SPEED_BUTTON)) {
//                leftvalue *= HI_SCALE;
//                rightvalue *= HI_SCALE;
//            }
//        } else {
//            if (leftStick.getRawButton(ALT_SPEED_BUTTON)) {
//                leftvalue *= LO_SCALE;
//                rightvalue *= LO_SCALE;
//            }
//        }
        setLMotor(leftvalue);
        setRMotor(rightvalue);
        if (rightStick.getRawButton(SHIFT_UP_BUTTON) )
            desiredShift = true;
        else if (rightStick.getRawButton(SHIFT_DOWN_BUTTON)) 
            desiredShift = false;
        updateShifters();
    }
}
