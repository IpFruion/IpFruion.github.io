/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Encoder;

/**
 *
 * @author Martin Wickham (MartinWickham@comcast.net)
 */
public class RPSMotor {
    public static final double DS = 0.01;
    
    private Motor motor;
    private Encoder encoder;
    private double rps;
    
    public RPSMotor(int encoderPortA, int encoderPortB, boolean can, int motorPort) {
        this.encoder = new Encoder(encoderPortA, encoderPortB);
        encoder.setDistancePerPulse(1/256);
        if (can) 
            this.motor = new CANMotor(motorPort);
        else
            this.motor = new PWMMotor(motorPort);
    }
    
    public void setTargetRPS(double target) {
        rps = target;
    }
    
    public void update() {
        if (rps < encoder.getRate()) {
            motor.set(Math.min(motor.get()+DS, 1));
        } else if (rps > encoder.getRate()) {
            motor.set(Math.max(motor.get()-DS, -1));            
        }
    }
    
    public double getActualRPS() {
        return encoder.getRate();
    }
}
