package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.Joystick;
/**
* The slapper that manipulates the bridge
* @author Brian
*/
public class BridgeSlap extends Component {
//   private int timer;
   Piston bPiston;
   public BridgeSlap(int portOut, int portIn) {
       bPiston = new Piston(portOut, portIn);
   }
   /**
    * updates the state of the slapper during autonomous
    * @param leftStick
    * @param rightStick
    * @param manipStick 
    */
   public void update(Joystick leftStick, Joystick rightStick, Joystick manipStick) {
       if (rightStick.getRawButton (BRIDGE_HIGH_BUTTON))
           bPiston.retract();
       else if (rightStick.getRawButton(BRIDGE_LOW_BUTTON))
           bPiston.extend();
       
//       if (!bPiston.isExtended())
            //bPiston.set(rightStick.getRawButton(BRIDGE_LOW_BUTTON));
//        else if (timer >= BRIDGE_SLAP_TIME) {
//            timer = 0;
//            bPiston.set(false);
//        } else {
//            timer++;
//        }
//        if (!SimpleLCD.getInstance().monitor("Slap Timer: "+timer, 5)) {
//            SimpleLCD.getInstance().monitor("Error", 1);
//        }
   }
   
   /**
    * pulls the slapper up
    */
    public void up() {
        bPiston.set(false);
    }
    
    /**
     * pushes the slapper down
     */
    void down() {
        bPiston.set(true);
    }
}