package edu.wpi.first.wpilibj.templates;
/**
 * @author FRC Team 2220
 */
public interface Constants {
    
    //Important changes
    public static final boolean MANUAL_COLUMN = true,
                                CAN_ROBOT = false;
    
    public static final int DEBUG_INPUT = 4;
    
    //ports
    public static final int LEFT_STICK_PORT = 1,         //begin Joystick ports
                            RIGHT_STICK_PORT = 2,
                            MANIP_STICK_PORT = 3,
            
                            // Motor Ports
                            DRIVE_LEFT_JAGUAR_PORT = 1,
                            DRIVE_RIGHT_JAGUAR_PORT = 2,
                            SHOT_JAGUAR_LO_PORT = 3,
                            SHOT_JAGUAR_HI_PORT = 4,
                            COLL_JAG_HI_PORT = 5,
                            COLL_JAG_LO_PORT = 6,
                            
                            // Solenoid Ports
                            DRIVE_SHIFTER_RE_PORT = 2,
                            DRIVE_SHIFTER_EX_PORT = 1,
                            BRIDGE_UP_PORT = 3,
                            BRIDGE_DOWN_PORT = 4,
                            DUMPER_RAISE_PORT = 5,
                            DUMPER_LOWER_PORT = 6,
                            DUMPER_CLOSE_PORT = 7,
                            DUMPER_OPEN_PORT = 8,
            
                            // Relay Ports
                            COMPRESSOR_SPIKE_PORT = 1,
                            //COLL_RELAY_HI_PORT = 2,
                            //COLL_RELAY_LO_PORT = 3,
                            
                            // Digital IO Ports
                            COMPRESSOR_SENSOR_PORT = 1,
                            COLL_SENSOR_LO_PORT = 2,
                            COLL_SENSOR_MID_PORT = 3,
                            COLL_SENSOR_HI_PORT = 4,
                            SHOT_LO_ENC_PORT_A = 5,
                            SHOT_LO_ENC_PORT_B = 6,
                            SHOT_HI_ENC_PORT_A = 7,
                            SHOT_HI_ENC_PORT_B = 8,
                            AUTO_NO_BACK_PORT = 14,
                                    
                            
                            //Analog IO Ports
                            FRONT_ULTRA_PORT = 1;
    
    
    
    
    //right stick controls
    public static final int //SHOT_START_BUTTON = -1,
                            SHIFT_UP_BUTTON = 5,
                            SHIFT_DOWN_BUTTON = 4,
                            BRIDGE_HIGH_BUTTON = 3,
                            BRIDGE_LOW_BUTTON = 2;
    
    //manip stick controls
    public static final int COL_HI_ON_BUTTON_1 = 7,
                            COL_HI_OFF_BUTTON_1 = 8,
                            COL_LO_ON_BUTTON_1 = 9,
                            COL_LO_OFF_BUTTON_1 = 10,
                            COL_LO_REV_BUTTON = 2,
                            COL_HI_REV_BUTTON = 12,
                            FAR_SHOT_BUTTON = 6,
                            CLOSE_SHOT_BUTTON = 5,
                            BRIDGE_SHOT_BUTTON = 11;
                            //Trigger = cannon toggle
    
    
    
    
    public static final int DRIVE_INDEX = 0,
                            SHOOT_INDEX = 1,
                            SLAP_INDEX = 2,
                            COMP_INDEX = 3,
                            LCD_INDEX = 4,
                            COMP_SIZE = 5;
    
    
    public static final int DRIVE_TARGET_LINE = 0,
                            DRIVE_ACTUAL_LINE = 1,
                            CANNON_LINE = 2,
                            CANNON_SPEED_LINE = 3,
                            COLUMN_LINE = 4,
                            DISTANCE_LINE = 5;
    
    
    
    public static final int SHOT_PUSH_TIME = 40,
                            BRIDGE_SLAP_TIME = 40;
    
    
    
    public static final int ULTRA_SMOOTHING = 10,
                            ENCODER_SMOOTHING = 10;
    
    
    
    
    public static final double SHOT_SPEED_SCALE = 0.75;
}
