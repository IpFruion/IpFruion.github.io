/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.CANJaguar;
/**
 * A motor that is controlled by a CANJaguar
 * @author Grant Ebeling
 */

public class CANMotor extends Motor {
    CANJaguar jag;
    
    public CANMotor(int port){
        try{
            jag = new CANJaguar(port);
        }
        catch(Exception e){
            DebugManager.getInstance().println(e);
        }
    }
    
    public double get(){
        try{
            return jag.getX();
        }
        catch(Exception e){
            DebugManager.getInstance().println(e);
        }
        return 0.;
    }
    
    public void set(double d){
        try{
            jag.setX(d);
        }
        catch(Exception e)
        {
            DebugManager.getInstance().println(e);
        }
    }
    
}
