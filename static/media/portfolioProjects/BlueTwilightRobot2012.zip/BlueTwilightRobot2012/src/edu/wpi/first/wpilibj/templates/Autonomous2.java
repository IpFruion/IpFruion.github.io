/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;

/**
 *
 * @author Dlock
 */
import edu.wpi.first.wpilibj.Jaguar;
//import edu.wpi.first.wpilibj.CANJaguar;
public class Autonomous2 {
    /*
     * This is where you have comments and start the 
     * design 
     */
    
    final int CIM_RPM = 5310;
    static long goTimeLength = 0;
    static long goTimeDegree = 0;
    final int DIAMETER = 8;
    final double SPEED_LOSS_CONSTANT = .81;
    final double WHEELS = 3;
    final double LOW_GEAR_CONSTANT = 0.0469;
    final double ADJUSTED_SPEED_CONSTANT = 0.3048*60;
    final int LENGTH = 3;
    final int DEGREE = 60;
    final int LENGTH_ROBOT = 37;
    
    
    public void run(DriveTrain dt) {
       

       int count = 3;
       //start of constants
       final double FORWARD_SPEED = .5;
       final double BACKWARD_SPEED = -.5;
       final int JAGUAR_PORT = 1;
       final int JAGUAR_PORT2 = 2;
       
       Jaguar pantherleft = new Jaguar(JAGUAR_PORT);
       Jaguar pantherRight = new Jaguar(JAGUAR_PORT2);
       //end of definitions
       //start of robot
       equation();
       for (;count<=3;count++) {
           pantherleft.set(FORWARD_SPEED);
           pantherRight.set(BACKWARD_SPEED);
           time(goTimeLength);
           pantherleft.set(0);
           pantherRight.set(0);
           pantherleft.set(BACKWARD_SPEED);
           pantherRight.set(BACKWARD_SPEED);
           time(goTimeDegree);
           pantherleft.set(0);
           pantherRight.set(0);
           
       }
       
    }
    public void equation() {
       double circumference;
       double adjustedSpeed;
       double maxWheelRPM;
       double circumferenceOfTurn;
       double lengthTurn;
       circumference = Math.PI * DIAMETER *WHEELS;
       maxWheelRPM = CIM_RPM*LOW_GEAR_CONSTANT*SPEED_LOSS_CONSTANT;
       adjustedSpeed = maxWheelRPM * circumference/ADJUSTED_SPEED_CONSTANT;
       System.out.println("Adjusted Speed: "+ adjustedSpeed);
       goTimeLength = (long)(LENGTH/adjustedSpeed)*1000;
       circumferenceOfTurn = 2*Math.PI*(LENGTH_ROBOT/2);
       lengthTurn = (DEGREE * circumferenceOfTurn)/360;
       goTimeDegree = (long)(lengthTurn/adjustedSpeed)*1000;
    }
    public void time(long x) {
        try{Thread.sleep(x);}catch(Exception e){}
    }
     //define data
        //variables
            //count = 3 - counts how many iterations of command
            //goTimeLength = (TBD) - how long the motors have to be on to achieve
            //                       LENGTH
            //goTimeDegree = (TBD) - how long the motors have to be on to achieve
            //                       Degree
        //constants
            //LENGTH = 3 - length from wheel to corner
            //DEGREE = 60 - degrees turned
    //start robot in autonomous
    //do the math to find goTimeLength
        //use length
    //do the math to find goTimeDegree
    //start for loop of count
        //drive forward goTimeLength
        //Turn goTimeDegree
    //end of loop
    //stop robot
}
