package edu.wpi.first.wpilibj.templates;

import java.io.PrintStream;

/**
 * @author Martin Wickham (MartinWickham@comcast.net)
 */
public class DebugManager implements Constants {
    
    private boolean canPrint;
    private PrintStream out;
    private static DebugManager instance;
    
    public static DebugManager getInstance() {
        if (instance == null) instance = new DebugManager();
        return instance;
    }
    
    protected DebugManager() {
        this.out = System.out;
    }
    
    public void set(boolean print) {
        canPrint = print;
    }
    
    public boolean canPrint() {
        return canPrint;
    }
    
    public void print(Object x) {
        if (canPrint())
            out.print(x);
    }
    public void print(boolean x) {
        if (canPrint())
            out.print(x);
    }
    public void print(byte x) {
        if (canPrint())
            out.print(x);
    }
    public void print(short x) {
        if (canPrint())
            out.print(x);
    }
    public void print(int x) {
        if (canPrint())
            out.print(x);
    }
    public void print(long x) {
        if (canPrint())
            out.print(x);
    }
    public void print(float x) {
        if (canPrint())
            out.print(x);
    }
    public void print(double x) {
        if (canPrint())
            out.print(x);
    }
    public void print(String x) {
        if (canPrint())
            out.print(x);
    }
    
    public void println() {
        if (canPrint())
            out.println();
    }
    public void println(Object x) {
        if (canPrint())
            out.println(x);
    }
    public void println(boolean x) {
        if (canPrint())
            out.println(x);
    }
    public void println(byte x) {
        if (canPrint())
            out.println(x);
    }
    public void println(short x) {
        if (canPrint())
            out.println(x);
    }
    public void println(int x) {
        if (canPrint())
            out.println(x);
    }
    public void println(long x) {
        if (canPrint())
            out.println(x);
    }
    public void println(float x) {
        if (canPrint())
            out.println(x);
    }
    public void println(double x) {
        if (canPrint())
            out.println(x);
    }
    public void println(String x) {
        if (canPrint())
            out.println(x);
    }
}
