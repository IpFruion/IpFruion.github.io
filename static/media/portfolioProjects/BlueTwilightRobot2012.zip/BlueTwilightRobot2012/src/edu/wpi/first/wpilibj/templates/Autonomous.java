/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.Jaguar;
import edu.wpi.first.wpilibj.CANJaguar;


/**
 *
 * @author Dlock
 */
public class Autonomous implements Constants {
    
    private CANJaguar leftCAN, rightCAN;
    private Jaguar left, right;
    int leftJagPort = 1;
    int rightJagPort = 2;
    
    public void run(boolean useCAN) {
        
        if (useCAN) {
            try {
            leftCAN = new CANJaguar(leftJagPort);
            rightCAN = new CANJaguar(rightJagPort);}
            catch (Exception e) {
            }
        } else {
            left = new Jaguar(leftJagPort);
            right = new Jaguar(rightJagPort);
        }
        
        process();
        
    }
    public void time(float x) {
        try{Thread.sleep((long)(x*1000));} catch(Exception e) {}
    }
    public void process() {
        left.set(.5);
        right.set(.5);
        time(2);
        reset();
        left.set(.5);
        right.set(-.5);
        time(1);
        reset();
        left.set(.5);
        right.set(.5);
        time(2);
        reset();
    }
    public void reset() {
        left.set(0);
        right.set(0);
        time(1);
    }    
}
