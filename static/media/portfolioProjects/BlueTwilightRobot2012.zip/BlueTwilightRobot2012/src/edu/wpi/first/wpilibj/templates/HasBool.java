package edu.wpi.first.wpilibj.templates;

public interface HasBool {
    public boolean get();
}