package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.DriverStationLCD;
import edu.wpi.first.wpilibj.DriverStationLCD.Line;
import edu.wpi.first.wpilibj.Joystick;
/**
 * Let me know if you use this code! I'd like to hear
 * whether it worked or not, and that there are teams that use it.
 * @author ArchVince
 * team 1290
 */
public class SimpleLCD extends Component {
    
    //the SimpleLCD will update once every <code>UPDATE_SPEED</code> cycles
    public static final int UPDATE_SPEED = 20;
    
    private static SimpleLCD instance;
    public static SimpleLCD getInstance() {
        if (instance == null) instance = new SimpleLCD();
        return instance;
    }
    
    
    private String[] print;
    private String over, overflow;
    private Object[] moniAr;
    private Line[] lines;
    private String[] lastMsg;
    private int watching;
    private int counter;

    public SimpleLCD(){
        watching = 0;
        moniAr = new Object[6];
        lines = new Line[6];
        lastMsg = new String[6];
        lines[0] = Line.kMain6;
        lines[1] = Line.kUser2;
        lines[2] = Line.kUser3;
        lines[3] = Line.kUser4;
        lines[4] = Line.kUser5;
        lines[5] = Line.kUser6;
        counter = 0;
        over = " ";
        for(int y = 1; y < DriverStationLCD.kLineLength; y++) over += " ";
        print = new String[6];
        for(int x = 0; x < print.length; x++) print[x] = " ";
        for(int x = 0; x < print.length; x++) for(int y = 1; y < DriverStationLCD.kLineLength; y++) print[x] += " ";
    }
    
    public void update(Joystick leftStick, Joystick rightStick, Joystick manipStick) {
        if (counter >= UPDATE_SPEED) {
            update();
            counter = 0;
        }
        counter++;
    }
    
    public void update(){
        int curr = 0;
        for(int x = 0; x < 5; x++){
            if(moniAr[x]!=null){
                String msg = moniAr[x].toString();
                if (msg != lastMsg[x]) {
                    DriverStationLCD.getInstance().println(lines[curr], 1, over);
                    DriverStationLCD.getInstance().println(lines[curr], 1, msg);
                    DriverStationLCD.getInstance().updateLCD();
                    lastMsg[x] = msg;
                }
                curr++;
            }
        }
    }
    public boolean stopMonitor(int line){
        if(moniAr[line] == null) return false;
        moniAr[line] = null;
        watching--;
        return true;
    }
    public boolean monitor(Object watch, int line){
        if(watching == lines.length && moniAr[line] == null) return false;
        if(moniAr[line] == null) watching++;
        moniAr[line] = watch;
        return true;
    }
    public void output(String out){
        overflow = "";
        if(out.length()>DriverStationLCD.kLineLength)out.substring(DriverStationLCD.kLineLength);
        for(int x = watching; x < lines.length; x++) print[x] = print[x+1];
        print[5] = out;
        cls();
        for(int x = watching; x < lines.length; x++) DriverStationLCD.getInstance().println(lines[x], 1, print[x]);
        DriverStationLCD.getInstance().updateLCD();
        if(!overflow.equals("")) output(overflow);
    }
    public void cls(){
        for(int x = watching; x < lines.length; x++) DriverStationLCD.getInstance().println(lines[x], 1, over);
        DriverStationLCD.getInstance().updateLCD();
    }
}