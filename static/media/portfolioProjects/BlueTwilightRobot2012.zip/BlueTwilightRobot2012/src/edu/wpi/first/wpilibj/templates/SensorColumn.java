/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.Joystick;

/**
 *
 * @author Martin Wickham (MartinWickham@comcast.net)
 */
public class SensorColumn extends Column {
    
    protected DigitalInput topSensor;
    protected DigitalInput midSensor;
    protected DigitalInput lowSensor;
    
    public SensorColumn(int hiSensor, int medSensor, int loSensor,
                         int hiPort, int loPort, boolean useCAN) {
        super(hiPort, loPort, useCAN);
        topSensor = new DigitalInput(hiSensor);
        midSensor = new DigitalInput(medSensor);
        lowSensor = new DigitalInput(loSensor);
    }

    public void update(Joystick leftStick, Joystick rightStick, Joystick manipStick) {
        
        if(!topSensor.get())
            setHi(Boolean.TRUE);
        else
            setHi(Boolean.FALSE);
        
        if(!midSensor.get())
            setLo(Boolean.TRUE);
        else
            setLo(Boolean.FALSE);
    }

}
