/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.DriverStation;


/**
 *
 * @author Martin Wickham (MartinWickham@comcast.net)
 */
public class ManualCannon extends Cannon {
    public static final double MIN_SPEED = 0.6;
    private boolean running;
    private boolean lastTrigger;
    private boolean useCloseShotOn = true;
    private boolean useBridge = false;
    private double bridgeLoSpeed = 1.0,
                                bridgeHiSpeed = 0.50,
                                closeLoSpeed, 
                                closeHiSpeed,
                                farLoSpeed,
                                farHiSpeed;
    
    public ManualCannon(int cannonJagLo, int cannonJagHi, boolean useCAN, int loEncA, int loEncB, int hiEncA, int hiEncB) {
        super(cannonJagLo, cannonJagHi, useCAN, loEncA, loEncB, hiEncA, hiEncB);
        running = false;
        SimpleLCD.getInstance().monitor(new Messenger("Shooter is ON","Shooter is OFF",new HasBool() {
            public boolean get() {
                return running;
            }
        }), CANNON_LINE);
        SimpleLCD.getInstance().monitor(this, CANNON_SPEED_LINE);
    }
    
    public void setSpeeds(double closeLo, double closeHi, double farLo, double farHi) {
        closeLoSpeed = closeLo;
        closeHiSpeed = closeHi;
        farLoSpeed = farLo;
        farHiSpeed = farHi;
    }
    
    public void updateSpeed(Joystick leftStick, Joystick rightStick, Joystick manipStick) {
        boolean currTrigger = manipStick.getTrigger();
        
        if (manipStick.getRawButton(BRIDGE_SHOT_BUTTON)) {
            useBridge = true;
        }
        else if ((manipStick.getRawButton(FAR_SHOT_BUTTON) || manipStick.getRawButton(CLOSE_SHOT_BUTTON))) {
            // A change to the shot distance has been requested,
            //  find out which is desired.
            useBridge = false;
            if (manipStick.getRawButton(FAR_SHOT_BUTTON))
                useCloseShotOn = false;
            else
                useCloseShotOn = true;
        }
         
        
        if (currTrigger != lastTrigger && currTrigger) {
            running = !running;
        }
        if (running) {
            if (useBridge) {
                this.setShotSpeed(bridgeLoSpeed, bridgeHiSpeed);
            } else {
//                if (useCloseShotOn)
//                    setShotSpeed(DriverStation.getInstance().getAnalogIn(3),
//                  DriverStation.getInstance().getAnalogIn(4));
//                else
//                    setShotSpeed(DriverStation.getInstance().getAnalogIn(1),
//                  DriverStation.getInstance().getAnalogIn(2));
                if (useCloseShotOn)
                    setShotSpeed(closeLoSpeed,
                            closeHiSpeed);
                else
                    setShotSpeed(farLoSpeed,
                            farHiSpeed);
            }
            //setShotSpeed((-manipStick.getThrottle()+1.)*(1-MIN_SPEED/2.)+MIN_SPEED);
        } else {
            setShotSpeed(0);
        }
        lastTrigger = currTrigger;
    }
    
    public String toString() {
        if (useBridge) return "Shooter is BRIDGE";
        else return useCloseShotOn?"Shooter is CLOSE":"Shooter is FAR";
    }
}
