/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.Relay.Value;
/**
 *
 * @author Martin Wickham (MartinWickham@comcast.net)
 */
public abstract class Column implements Constants {
    
    public static final double MOTOR_SPEED = 1.;
    
    //protected Relay loRelay;
    //protected Relay hiRelay;
    protected Motor loMotor;
    protected Motor hiMotor;
    
    protected Column(int hiPort, int loPort, boolean useCAN) {
//        this.loRelay = new Relay(hiPort, Relay.Direction.kBoth);
//        this.hiRelay = new Relay(loPort, Relay.Direction.kReverse);
        if (useCAN) {
            this.loMotor = new CANMotor(loPort);
            this.hiMotor = new CANMotor(hiPort);
        } else {
            this.loMotor = new PWMMotor(loPort);
            this.hiMotor = new PWMMotor(hiPort);
        }
        SimpleLCD.getInstance().monitor(this, COLUMN_LINE);
    }
    
    public abstract void update(Joystick leftStick, Joystick rightStick, Joystick manipStick);
    
    public void setHi(Boolean on) {
        //hiRelay.set(on?Relay.Value.kOn:Relay.Value.kOff);
        if (on == null) hiMotor.set(-MOTOR_SPEED);
        else if (on.booleanValue()) hiMotor.set(MOTOR_SPEED);
        else hiMotor.set(0);
    }
    
    public void setLo(Boolean on) {
//        if (on == null) loRelay.set(Value.kForward);
//        else if (on.equals(Boolean.TRUE)) loRelay.set(Value.kReverse);
//        else loRelay.set(Value.kOff);
        if (on == null) loMotor.set(MOTOR_SPEED);
        else if (on.booleanValue()) loMotor.set(-MOTOR_SPEED);
        else loMotor.set(0);
    }
    
    public String toString() {
        return "Lo: "+loState()+" Hi: "+hiState();
    }
    
    public String loState() {
        if (loMotor.get() == 0) {
            return "OFF ";
        } else if (loMotor.get() == MOTOR_SPEED) {
            return "BACK";
        } else {
            return "ON  ";
        }
    }
    
    public String hiState() {
        if (hiMotor.get() == 0) {
            return "OFF";
        } else {
            return "ON ";
        }
    }
}
