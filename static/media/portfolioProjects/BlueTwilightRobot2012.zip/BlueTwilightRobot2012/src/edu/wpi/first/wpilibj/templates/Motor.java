/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Robotics
 */
package edu.wpi.first.wpilibj.templates;
public abstract class Motor implements Constants {
    
    public abstract void set(double d);
    public abstract double get();
    
}
