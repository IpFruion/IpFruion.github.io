/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Joystick;

/**
 *
 * @author Martin Wickham (MartinWickham@comcast.net)
 */
public class ManualColumn extends Column {
    private boolean loVal;
    private boolean hiVal;
    public ManualColumn(int hiPort, int loPort, boolean useCAN) {
        super(hiPort, loPort, useCAN);
    }
    
    public void update(Joystick leftStick, Joystick rightStick, Joystick manipStick) {
        if (manipStick.getRawButton(COL_LO_REV_BUTTON))
            setLo(null);
        else {
            if(manipStick.getRawButton(COL_LO_ON_BUTTON_1) /*|| manipStick.getRawButton(COL_LO_ON_BUTTON_2)*/)
                loVal = true;
            else if (manipStick.getRawButton(COL_LO_OFF_BUTTON_1) /*|| manipStick.getRawButton(COL_LO_OFF_BUTTON_2)*/)
                loVal = false;
            setLo(loVal?Boolean.TRUE:Boolean.FALSE);
        }
        
        if (manipStick.getRawButton(COL_HI_REV_BUTTON)) 
            setHi(null);
        else {
            if(manipStick.getRawButton(COL_HI_ON_BUTTON_1) /*|| manipStick.getRawButton(COL_HI_ON_BUTTON_2)*/)
                hiVal = true;
            else if (manipStick.getRawButton(COL_HI_OFF_BUTTON_1) /*|| manipStick.getRawButton(COL_HI_OFF_BUTTON_2)*/)
                hiVal = false;
            setHi(hiVal?Boolean.TRUE:Boolean.FALSE);
        }
    }
}
