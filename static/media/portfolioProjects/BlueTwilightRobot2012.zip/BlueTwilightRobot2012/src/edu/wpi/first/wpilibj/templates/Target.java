/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.camera.AxisCamera;
import edu.wpi.first.wpilibj.camera.AxisCameraException;
import edu.wpi.first.wpilibj.image.BinaryImage;
import edu.wpi.first.wpilibj.image.NIVisionException;
import edu.wpi.first.wpilibj.image.ParticleAnalysisReport;


/**
 *
 * @author Dlock
 */
public class Target {
   
    
    public static final int hMax = 162,
                            hMin = 82,
                            sMax = 100,
                            sMin = 35,
                            vMax = 50,
                            vMin = 100;
    
    public static final int numProb = 4;
    
    public static ParticleAnalysisReport[] findHoop() {
            try {
                
                BinaryImage image = AxisCamera.getInstance().getImage().thresholdHSV(hMax, hMin, sMax, sMin, vMax, vMin);
            
                ParticleAnalysisReport[] reps = image.getOrderedParticleAnalysisReports();
            
    /*            for (int n = 0; n<reps.length && n<6; n++){
                    System.out.println(reps[n] + "\n");
                }
         */      
                
                ParticleAnalysisReport[] prob = new ParticleAnalysisReport[Math.min(numProb, reps.length)];
                for(int n = 0; n<reps.length && n<numProb; n++) {
                    prob[n] = reps[n];
                }
                return prob;
            
            }catch (AxisCameraException ex) {}
             catch (NIVisionException ex) {}
            return null;
        
    }
    public static void process() {
        ParticleAnalysisReport[] prob = findHoop();
        int rup;
        String name;
        double[] goodParticle = new double[3];
        
        for(rup = 0; rup<=3; rup++) {
            if(prob[rup].particleToImagePercent < 1 && prob[rup].particleToImagePercent > .5) {
                System.out.println("Green stuff in image in PAR: " + rup);
                goodParticle[rup] = prob[rup].particleToImagePercent;
            }
            else {
                System.out.println("No Green stuff in image in PAR: " + rup);
                System.out.println("Trashing...");
                
            }
                
        }
        System.out.println(prob[0]);
        
    }

    
    /* coding scheme
     * -1 = backwards (no idea)
     * 0 = Straight
     * 1 = left
     * 2 = right
     */
    public static int getDirection() {
        return -1;
    }
    public static int getDistance() {
        return 0;
    }
    public static int getSpeed() {
        return 0;
    }
}