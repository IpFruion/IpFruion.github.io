/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;
import edu.wpi.first.wpilibj.Jaguar;

/**
 *
 * @author Robotics
 */
public class PWMMotor extends Motor {
    Jaguar jag;
    public PWMMotor(int port){
        jag = new Jaguar(port);
    }
    public double get(){
        return jag.get();
    }
    public void set(double d){
        jag.set(d);
    }
}
