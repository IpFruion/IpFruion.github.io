/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;

/**
 * a base autonomous class
 * @author Martin Wickham (MartinWickham@comcast.net)
 */
public abstract class AutoBase implements Constants {
    protected Shooter shooter;
    protected BridgeSlap slapper;
    protected DriveTrain drive;
    protected CompressorComp compressor;
    
    /**
     * creates an autonomous program
     * @param comps the component array
     */
    protected AutoBase(Component[] comps) {
        shooter = (Shooter)comps[SHOOT_INDEX];
        slapper = (BridgeSlap)comps[SLAP_INDEX];
        drive = (DriveTrain)comps[DRIVE_INDEX];
        compressor = (CompressorComp)comps[COMP_INDEX];
    }
    
    /**
     * runs autonomous
     */
    public abstract void run();
    
    public void sleep(int millis) {
        try{Thread.sleep(millis);}catch(Exception e){DebugManager.getInstance().println(e);}
    }
}
