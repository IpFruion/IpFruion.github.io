package edu.wpi.first.wpilibj.templates;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Grant Ebeling
 * @author Martin Wickham
 */
import edu.wpi.first.wpilibj.Joystick;

public class Shooter extends Component {
    
    private Column col;
    private Cannon can;
    
    public Shooter(Column col, Cannon can) {
        this.col = col;
        this.can = can;
    }
    
    public final void update(Joystick leftStick, Joystick rightStick, Joystick manipStick) {
        col.update(leftStick, rightStick, manipStick);
        can.update(leftStick, rightStick, manipStick);
    }
    
    public Column getColumn() {
        return col;
    }
    
    public Cannon getCannon() {
        return can;
    }
}