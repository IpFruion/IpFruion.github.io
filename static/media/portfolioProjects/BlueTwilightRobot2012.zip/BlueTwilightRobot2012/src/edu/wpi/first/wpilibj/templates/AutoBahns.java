/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.DriverStation;

/**
 * our main autonomous program - shoots twice, then backs if DI4 and hits the middle bridge
 * @author Brian, Martin
 */
public class AutoBahns extends AutoBase {
    public AutoBahns(Component[] comps, int noMoveBackPort) {
        super(comps);
    }
    public final static int SHOOT_TIME = 5200;
    public final static int BACK_TIME_STRAIGHT = 2200;
    public final static int BACK_TIME_DIAG = 2600;
//    public static final int SLOW_TIME = 1000;
//    public final static int SLAP_TIME = 4000;
    public final static double BACK_SPEED = 1;
    public final static double START_SPEED = .77,
                               END_SPEED = .87;
    
    /**
     * runs autonomous
     */
    public void run() {
        shooter.getCannon().setTopSpeed(DriverStation.getInstance().getAnalogIn(2));
        shooter.getCannon().setBotSpeed(DriverStation.getInstance().getAnalogIn(1));
        shooter.getColumn().setLo(Boolean.TRUE);
        shooter.getColumn().setHi(Boolean.TRUE);
        if (!DriverStation.getInstance().getDigitalIn(3)) {
            DebugManager.getInstance().println("no move back in auto");
            return;
        }
        sleep(SHOOT_TIME);
        drive.setRMotor(BACK_SPEED);
        drive.setLMotor(BACK_SPEED);
        shooter.getCannon().setTopSpeed(DriverStation.getInstance().getAnalogIn(2));
        shooter.getCannon().setBotSpeed(DriverStation.getInstance().getAnalogIn(1));
        if (DriverStation.getInstance().getDigitalIn(2)) {
            sleep(BACK_TIME_DIAG);
        } else {
            sleep(BACK_TIME_STRAIGHT);            
        }
        drive.setLMotor(0);
        drive.setRMotor(0);
        slapper.down();
    }
}
