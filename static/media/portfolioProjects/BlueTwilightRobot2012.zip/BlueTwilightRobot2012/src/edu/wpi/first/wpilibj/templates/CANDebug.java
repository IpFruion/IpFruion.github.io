/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.CANJaguar;
import edu.wpi.first.wpilibj.can.CANTimeoutException;

/**
 * A utility class that is compatible with the SimpleLCD and can be directly added
 * @author Martin Wickham (MartinWickham@comcast.net)
 */
public class CANDebug extends CANJaguar {
    public CANDebug(int port) throws CANTimeoutException {
        super(port);
    }
    
    /**
     * starts monitoring this on the given line via the SimpleLCD
     * @param line
     * @return 
     */
    public boolean monitor(int line) {
        return SimpleLCD.getInstance().monitor(this, line);
    }
    
    /**
     * displays PID for the CANJaguar
     * @return 
     */
    public String toString() {
        try {
            return "P:"+round(getP())+" I:"+round(getI())+" D:"+round(getD());
        } catch(CANTimeoutException e) {
            return "Timeout Exception??";
        }
    }
    
    /**
     * rounds the given number to the hundredths place
     * @param num
     * @return 
     */
    public static double round(double num) {
        return ((double)((int)(num*100.)))/100.;
    }
}
