/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.Joystick;

/**
 *
 * @author Martin Wickham (MartinWickham@comcast.net)
 */
public class CompressorComp extends Component {
    
    private Compressor comp;
    
    public CompressorComp(int sensorPort, int relayPort) {
        comp = new Compressor(sensorPort, relayPort);
    }

    public void update(Joystick leftStick, Joystick rightStick, Joystick manipStick) {
//        if (leftStick.getRawButton(COMP_ON_BUTTON))
//            start();
//        else if (leftStick.getRawButton(COMP_OFF_BUTTON))
//            stop();
    }
    
    public void start() {
        comp.start();
    }
    
    public void stop() {
        comp.stop();
    }
}
