/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.Joystick;

/**
 * a base class for a cannon
 * @author Martin Wickham (MartinWickham@comcast.net)
 */
public abstract class Cannon implements Constants {
    
    protected Motor hiCannonJag;
    protected Motor loCannonJag;
    protected final double ratio;
//    protected RPSMotor hiMotor;
//    protected RPSMotor loMotor;
    private double[] speeds = 
            {
                0.5,
                0.67,
                0.71,
                0.88,
                0.73,  //new battery
                0.82,
                       //new battery
                
            };
    
    protected Cannon(int cannonJagLo, int cannonJagHi, boolean useCAN, int loEncoderA, int loEncoderB, int hiEncoderA, int hiEncoderB) {
        if (useCAN) {
            hiCannonJag = new CANMotor(cannonJagHi);
            loCannonJag = new CANMotor(cannonJagLo);
        } else {
            hiCannonJag = new PWMMotor(cannonJagHi);
            loCannonJag = new PWMMotor(cannonJagLo);
        }
        ratio = SHOT_SPEED_SCALE;
//        loMotor = new RPSMotor(loEncoderA, loEncoderB, useCAN, cannonJagLo);
//        hiMotor = new RPSMotor(hiEncoderA, hiEncoderB, useCAN, cannonJagHi);
    }
    
    public void setShotSpeed(double lowSpeed, double hiSpeed) {
        hiCannonJag.set(-hiSpeed);
        loCannonJag.set(-lowSpeed);
    }
    
    public void setShotSpeed(double speed) {
        hiCannonJag.set(-speed*ratio);
        loCannonJag.set(-speed);
//        hiMotor.setTargetRPS(50*(1-speed)*SHOT_SPEED_SCALE);
//        loMotor.setTargetRPS(-50*(1-speed));
    }
    
    /**
     * sets the shot speed based on the given distance
     * never worked because of lack of experimental data
     * @deprecated
     * @param inches 
     */
    public void setSpeedDistance(double inches) {
        double feet = inches/12;
        int x2 = (int)Math.ceil(feet);
        if (x2 >= speeds.length) {
            setShotSpeed(1.0);
            return;
        }
        int x1 = (int)feet;
        double m = (speeds[x2]-speeds[x1])/(x2-x1);
        double b = speeds[x2]-(x2*m);
        setShotSpeed(m*feet+b);
    }
    
    /**
     * common update function
     * @param leftStick
     * @param rightStick
     * @param manipStick 
     */
    public final void update(Joystick leftStick, Joystick rightStick, Joystick manipStick) {
//        hiMotor.update();
//        loMotor.update();
//        ratio = (1-rightStick.getTwist())/2;
        updateSpeed(leftStick, rightStick, manipStick);
        
    }
    
    public String toString() {
//        return "Hi:"+CANDebug.round(hiMotor.getActualRPS())+" Lo:"+CANDebug.round(loMotor.getActualRPS());
        return "Lo:"+CANDebug.round(loCannonJag.get())+" r:"+CANDebug.round(ratio);
    }
    
    /**
     * lets the subimplementation add update steps
     * @param leftStick
     * @param rightStick
     * @param manipStick 
     */
    public abstract void updateSpeed(Joystick leftStick, Joystick rightStick, Joystick manipStick);

    void setTopSpeed(double speed) {
        hiCannonJag.set(-speed);
    }
    void setBotSpeed(double speed) {
        loCannonJag.set(-speed);
    }
}
