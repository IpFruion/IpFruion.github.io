/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;

/**
 *
 * @author Martin Wickham (MartinWickham@comcast.net)
 */
public class Messenger {
    HasBool check;
    String posMsg, negMsg;
    
    public Messenger(String posMsg, String negMsg, HasBool check) {
        this.check = check;
        this.posMsg = posMsg;
        this.negMsg = negMsg;
    }
    
    public String toString() {
        return check.get()?posMsg:negMsg;
    }
}
