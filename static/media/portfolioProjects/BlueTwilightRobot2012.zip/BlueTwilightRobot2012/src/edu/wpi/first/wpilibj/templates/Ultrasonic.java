/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.AnalogChannel;

/**
 *
 * @author Martin Wickham (MartinWickham@comcast.net)
 */

public class Ultrasonic implements Constants {
    public static final double VPI = 0.010192;
    
    private AnalogChannel ult;
    
    public Ultrasonic(int port, int smoothing) {
        ult = new AnalogChannel(port);
    }
    
    public double getDistance() {
       return 0;
    }
}
