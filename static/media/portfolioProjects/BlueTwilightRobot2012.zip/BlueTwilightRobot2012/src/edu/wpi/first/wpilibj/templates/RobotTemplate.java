/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package edu.wpi.first.wpilibj.templates;


import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.SimpleRobot;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class RobotTemplate extends SimpleRobot implements Constants {

    
    private Joystick leftStick;
    private Joystick rightStick;
    private Joystick manipStick;
    private DebugManager out;
    private Component[] components;
    private AutoBase auto;
    private Autonomous2 autonomous2 = new Autonomous2();
    
    /**
     * called at the beginning of each match
     */
    public void robotInit() {
        out = DebugManager.getInstance();
        out.set(false);
        out.print("Initializing... ");
        components = new Component[COMP_SIZE];
        leftStick = new Joystick(LEFT_STICK_PORT);
        rightStick = new Joystick(RIGHT_STICK_PORT);
        manipStick = new Joystick(MANIP_STICK_PORT);
        components[DRIVE_INDEX] = new DriveTrain(DRIVE_LEFT_JAGUAR_PORT, DRIVE_RIGHT_JAGUAR_PORT,
                                              DRIVE_SHIFTER_EX_PORT, DRIVE_SHIFTER_RE_PORT,
                                              FRONT_ULTRA_PORT, CAN_ROBOT);
        Column col;
        if (MANUAL_COLUMN) {
            col = new ManualColumn(COLL_JAG_HI_PORT, COLL_JAG_LO_PORT, CAN_ROBOT);
        } else {
            col = new SensorColumn(COLL_SENSOR_HI_PORT, COLL_SENSOR_MID_PORT, COLL_SENSOR_LO_PORT,
                              COLL_JAG_HI_PORT, COLL_JAG_LO_PORT, CAN_ROBOT);
        }
        Cannon can = new ManualCannon(SHOT_JAGUAR_LO_PORT, SHOT_JAGUAR_HI_PORT, CAN_ROBOT,
                SHOT_LO_ENC_PORT_A, SHOT_LO_ENC_PORT_B, SHOT_HI_ENC_PORT_A, SHOT_HI_ENC_PORT_B);
        components[SHOOT_INDEX] = new Shooter(col, can);
        components[SLAP_INDEX] = new BridgeSlap(BRIDGE_DOWN_PORT, BRIDGE_UP_PORT);
        components[COMP_INDEX] = new CompressorComp(COMPRESSOR_SENSOR_PORT, COMPRESSOR_SPIKE_PORT);
        components[LCD_INDEX] = SimpleLCD.getInstance();
        auto = new AutoBahns(components, AUTO_NO_BACK_PORT);
        out.println("done");
    }
    
    /**
     * This function is called once each time the robot enters autonomous mode.
     */
    public void autonomous() {
       
        out.println("Autonomous started");
        getWatchdog().setEnabled(false);
       // auto.run();
        autonomous2.run((DriveTrain)components[DRIVE_INDEX]);
        out.println("Autonomous ended");
        
     }
    
    /**
     * called when the robot is disabled
     */
    public void disabled() {
        out.print("Disabling... ");
        ((CompressorComp)components[COMP_INDEX]).stop();
        out.println("done");
    }

    /**
     * This function is called once each time the robot enters operator control.
     */
    public void operatorControl() {
        out.println("Operator Control started");
        getWatchdog().setEnabled(false);
        ((ManualCannon)((Shooter)components[SHOOT_INDEX]).getCannon())
                  .setSpeeds(DriverStation.getInstance().getAnalogIn(3),
                  DriverStation.getInstance().getAnalogIn(4),
                  DriverStation.getInstance().getAnalogIn(1),
                  DriverStation.getInstance().getAnalogIn(2));
        ((CompressorComp)components[COMP_INDEX]).start();
        //<editor-fold desc="lcd initialization">
        out.print("Initializing Messengers... ");
        SimpleLCD.getInstance().monitor(new Messenger("Shift target is High","Shift target is Low",
                        new HasBool() {
                            public boolean get() {
                                return ((DriveTrain)components[DRIVE_INDEX]).getTargetState();
                            }
                        }),DRIVE_TARGET_LINE);
        SimpleLCD.getInstance().monitor(new Messenger("You are in High gear","You are in Low gear",
                        new HasBool() {
                            public boolean get() {
                                return ((DriveTrain)components[DRIVE_INDEX]).getActualState();
                            }
                        }),DRIVE_ACTUAL_LINE);
        out.println("done");
        //</editor-fold>
        //<editor-fold desc="Main loop">
        out.println("Entering main loop");
        while (isOperatorControl()) {
            for (int c = 0; c < components.length; c++) {
                components[c].update(leftStick, rightStick, manipStick);
            }
        }
        out.println("Done with main loop");
        out.println("Done with operator control");
        //</editor-fold>
    }
}
