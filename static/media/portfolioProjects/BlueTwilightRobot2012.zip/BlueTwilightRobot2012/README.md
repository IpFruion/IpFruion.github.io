BlueTwilightRobot2013
=====================
Hello. This is the 2013 Robot Code Created by the EHS Robotic Team

Leads: 

-Derrick
-Tim

Members:

-Luke
-Abby

Rules:

1. To Change the code please Write your Commits with an explanation that states what you have done
2. Do not Change anything that states who is working on it unless you have Permission from them or you are a lead
3. If you are a member Remeber the leads are trusting you to make the write changes if you do not follow the rules or cannot comply with what the leads decide you will be taken off the project.
4. If you wish to help with an issue that is not your be sure to talk to the owner first.
5. If you have some code that you wish to see please make a Issue or Milestone but first talk to a lead about the Issue/Milestone.
6. This Repo is supposed to be a good way to get our Programming team good organization and sharing of code lets use it in this manner please
7. ENJOY CODING 

Robot Code 2013