/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bt.storage.joystick.modules;

import edu.wpi.first.wpilibj.Joystick;

/**
 *
 * @author Dlock
 */
public class BTJoystickButton implements BTConButton {

    int port;
    Joystick joy;
    boolean prevVal = false;
    public static final int BUTTON_AMOUNT_MAX = 12;

    public BTJoystickButton(Joystick joy, int port) {
        this.port = port;
        this.joy = joy;
        
    }

    public boolean getVal() {
        prevVal = joy.getRawButton(port);
        return prevVal;
    }

    public boolean getLeadingEdge() {
        boolean current = joy.getRawButton(port);
        boolean state = false;
        if (!prevVal && current) {
            state = true;
        }
        prevVal = current;
        return state;
    }

    public boolean getBackEdge() {
        boolean current = joy.getRawButton(port);
        boolean state = false;
        if (prevVal && !current) {
            state = true;
        }
        prevVal = current;
        return state;
    }

    public boolean getContinousEdge() {
        boolean current = joy.getRawButton(port);
        boolean state = false;
        if (prevVal && current) {
            state = true;
        }
        prevVal = current;
        return state;
    }
}
