/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bt.storage.components.motor;

/**
 *
 * @author Dlock
 */
public interface BTMotor {
    public void setX(double x);
    public double getX();
}
