/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package punnettsquarecalc;
import java.util.Scanner;


/**
 *
 * @author Dlock
 */
public class Punnettsquarecalc {
    static Scanner parents = new Scanner(System.in);
    static StringBuffer sb = new StringBuffer();
    static boolean doagain = true;
    static String[] parent1;
    static String[] parent2;
    static String[] tempresultchild;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    while (doagain) {
        
        System.out.print("Please type the number of genes: ");
        int num = parents.nextInt();
        if (num <= 0) {
            doagain = false;
        }
        System.out.print("Please enter the parent genes ex AaBbaabb: ");
        String gene = parents.next();
        process(gene, num);
        doagain = false;  
    }   
  }
    
public static void process(String g, Integer i) {
    
    System.out.println("This is the first parent genes: " + g.substring(0, i*2-1));
    System.out.println("This is the second parent genes: " + g.substring(i*2, i*4-1));
    
    String p1 = g.substring(0, i*2-1);
    String p2 = g.substring(i*2, i*4-1);
    int p = (int) Math.pow(2, i);
    int r = p/2;
    int addtrait = 0;
    int pn1;
    int pn2;
    
    parent1 = new String[p];
    parent2 = new String[p];
    tempresultchild = new String[p];
    
    for (pn1 = 0; pn1 < p1.length(); pn1++){
        parent1[pn1] = p1.substring(pn1);
        }    
    for (pn2 = 0; pn2 < p2.length(); pn2++) {
        parent2[pn2] = p2.substring(pn2);
        }
    for (int padd = 0; padd < 0; padd--) {
        sb.append(parent1[pn1]);
        sb.append(parent2[pn2]);
        
    }
    
    
   /*
    * for (int v = 1; v <= r; ) {
       
       char c = p1.charAt(0);
       parent1[addtrait] = Character.toString(c);
       addtrait++;
       
       v = v+1;
       
       for (int v1 = v; v1 <= r/2;) {
           
           sb.append(p1.charAt(2));
           v1 = v1+1;
           for (int v2 = v; v2 <= r/4;) {
               
           }
           
           
       }
       
   }
   */ 
    
}
    
public static void math(String g, Integer i) {  
    //Math.pow = power too
    for (int x = (int) Math.pow(4, i); x > 0 ; x = x-2) {
        
        
    
    
    }
  }
}
