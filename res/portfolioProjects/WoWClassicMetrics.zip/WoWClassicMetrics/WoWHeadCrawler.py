import ast
import queue as q
from html.parser import HTMLParser

import requests

from Util import FlagList, DataObject, traverse_construct

CLASSIC_WOWHEAD_URL = "https://classic.wowhead.com"

QUEST_URL = CLASSIC_WOWHEAD_URL + "/quest=?"
ITEM_URL = CLASSIC_WOWHEAD_URL + "/item=?"


def parse_related_tab(tab_str):
    # tab_str = tab_str.replace('\r', '').replace('\n', '')

    id_index = tab_str.index("id:")
    id = tab_str[id_index + 4:tab_str.index(",", id_index)]
    id = id.replace('\'', '')

    data_index = tab_str.index("data:") + 6

    data_str = traverse_construct(tab_str[data_index:])

    # lvl = 0
    # index = -1
    # data_str = tab_str[data_index:]
    # in_qoute = False
    # for i, c in enumerate(data_str):
    #     if c == '"':
    #         in_qoute = not in_qoute
    #     if in_qoute:
    #         continue
    #     if c == '[' or c == '{':
    #         lvl += 1
    #     elif c == ']' or c == '}':
    #         lvl -= 1
    #         if lvl == 0:
    #             index = i
    #             break
    #     elif c == ',' and lvl == 0:
    #         index = i
    #         break
    # data_str = tab_str[data_index:data_index + index]
    data_str = data_str.replace('\\', '')
    data_str = data_str.replace("false", "False")
    data_str = data_str.replace("true", "True")
    data_str = data_str.replace("null", "None")

    try:
        return id, ast.literal_eval(data_str)
    except:
        print(data_str)
        print(tab_str)
        raise ValueError("Malformed Exception")


class WoWHeadObject(DataObject):
    def __repr__(self):
        return "(" + str(self.id) + ", " + str(self.name) + ", " + str(self.link) + ")"


class Faction(WoWHeadObject):
    def __str__(self):
        return "Faction: " + str(self.name)


class Item(WoWHeadObject):
    def __str__(self):
        return "Item: " + str(self.name)


class Quest(WoWHeadObject):
    def __str__(self):
        return "Quest: " + str(self.name) + " : " + str(self.description)


class Npc(WoWHeadObject):
    def __str__(self):
        return "NPC: " + str(self.name)


class ItemParser(HTMLParser):

    def __init__(self):
        super().__init__()
        self.flags = FlagList(bool_identifier="in")
        self.item = None

    def fill_item(self, item, data):
        self.item = item
        super().feed(data)

    def handle_starttag(self, tag, attrs):
        if tag == "h2":
            self.flags.in_header = True
        if self.flags.in_related and tag == "script":
            self.flags.in_script = True

    def handle_data(self, data):
        if self.flags.in_header and data == "Related":
            self.flags.in_related = True
        if self.flags.in_script:
            if self.flags.in_related:
                splits = data.strip().split(";\n")
                splits = splits[1:]
                for tab in splits:
                    if tab == '':
                        continue
                    tab = traverse_construct(tab[tab.index('('):])
                    tab = " ".join(tab.split())
                    tab = tab[1:-1]
                    tab_id, tab_data = parse_related_tab(tab)
                    if tab_id == "reward-from-q":
                        for quest_dict in tab_data:
                            quest = Quest(id=quest_dict["id"], name=quest_dict["name"],
                                          link=QUEST_URL.replace('?', str(quest_dict["id"])))
                            self.item.reward_from_quest_list.append(quest)

                self.flags.in_related = False

        # if "reward-from-q" in data:
        #
        # if "dropped-by" in data:
        #     pass

    def handle_endtag(self, tag):
        if self.flags.in_header and tag == "h2":
            self.flags.in_header = False
        if self.flags.in_script and tag == "script":
            self.flags.in_script = False


class QuestParser(HTMLParser):

    def __init__(self):
        super().__init__()
        self.flags = FlagList(bool_identifier="in")
        self.item = None
        # TODO: Quest name, description, lvl, type, sharable, etc. requirements, unlocks

    def fill_quest(self, quest, data):
        self.quest = quest
        self.flags.reset()
        super().feed(data)

    def handle_starttag(self, tag, attrs):
        if tag == "title":
            self.flags.in_title = True
        if tag == "meta":
            if len(attrs) > 1:
                if attrs[0][0] == "name" and attrs[0][1] == "description":
                    self.quest.text = attrs[1][1].strip()
                elif attrs[0][0] == "property" and attrs[0][1] == "og:url":
                    self.quest.wowhead_link = attrs[1][1]
                    quest_str = attrs[1][1].split("/")[3]
                    self.quest.id = int(quest_str.split("=")[1])

        if tag == "table" and len(attrs) > 0 and attrs[0][0] == "class" and attrs[0][1] == "iconlist":
            self.flags.in_req_table = True
        if self.flags.in_req_table and tag == "tr":
            self.flags.in_requirement = True
        # TODO: Fix if href in different place?
        if self.flags.in_requirement and tag == "a" and len(attrs) > 0 and attrs[0][0] == "href":
            type = attrs[0][1][1:attrs[0][1].index("=")]
            id = int(attrs[0][1].split("=")[1].split("/")[0])
            link = CLASSIC_WOWHEAD_URL + attrs[0][1]
            if type == "item":
                self.flags.cur_requirement = Item(id=id, link=link)
            elif type == "faction":
                self.flags.cur_requirement = Faction(id=id, link=link)
            elif type == "npc":
                self.flags.cur_requirement = Npc(id=id, link=link)
        if tag == "h2":
            if self.flags.in_description:
                self.flags.in_description = False
            self.flags.in_header = True
        if self.flags.in_rewards and tag == "td":
            self.flags.in_reward_item = True
        if self.flags.in_rewards and tag == "script":
            self.flags.in_rewards_script = True

    def handle_data(self, data):
        if self.flags.in_header:
            if data.strip() == "Description":
                self.quest.description = ""
                self.flags.in_description = True
            elif data.strip() == "Rewards":
                self.quest.rewards_dict["items"] = []
                self.quest.rewards_dict["coins"] = 0
                self.quest.rewards_dict["rep"] = None
                self.flags.in_rewards = True
            elif data.strip() == "Gains":
                self.flags.in_rewards = False
        elif self.flags.in_description:
            self.quest.description += data.strip()

        if self.flags.in_title:
            self.quest.name = data.split("-")[0].strip()
        if self.flags.in_requirement and \
                self.flags.cur_requirement is not None and \
                self.flags.cur_requirement.link is not None and \
                self.flags.cur_requirement.name is None:
            self.flags.cur_requirement.name = data.strip()
        elif self.flags.in_requirement and \
                self.flags.cur_requirement is not None and \
                self.flags.cur_requirement.name is not None:
            self.flags.quantity_data = data.strip().replace("(", '').replace(")", '').replace("slain", '').strip()
        if self.flags.in_reward_item:
            self.flags.reward_item_name = data.strip()

        if self.flags.in_rewards_script:
            data = data.strip()
            splits = data.split(".createIcon(")
            i = 1
            for item in self.quest.rewards_dict["items"]:
                item.id = int(splits[i].split(",")[0])
                item.link = ITEM_URL.replace("?", str(item.id))
                i += 1
            self.flags.in_rewards_script = False

    def handle_endtag(self, tag):
        if self.flags.in_reward_item and tag == "td":
            self.quest.rewards_dict["items"].append(Item(name=self.flags.reward_item_name))
            self.flags.in_reward_item = False
        if tag == "h2":
            self.flags.in_header = False
        if tag == "title":
            self.flags.in_title = False
        if self.flags.in_req_table and tag == "table":
            self.flags.in_req_table = False
        if self.flags.in_requirement and tag == "tr":
            self.flags.in_requirement = False
            if self.flags.cur_requirement is not None:
                if self.flags.quantity_data is None:
                    self.flags.quantity_data = 1
                elif isinstance(self.flags.quantity_data, str):
                    if self.flags.quantity_data.isnumeric():
                        self.flags.quantity_data = int(self.flags.quantity_data)
                    elif self.flags.quantity_data == '':
                        self.flags.quantity_data = 1

                self.flags.cur_requirement.quantity_data = self.flags.quantity_data
                self.quest.requirements_list.append(self.flags.cur_requirement)
                self.flags.cur_requirement = None
                self.flags.quantity_data = None


class QuestCrawler(object):

    def __init__(self, quest_id):
        self.quest_id = quest_id
        self.quest_parser = QuestParser()
        self.item_parser = ItemParser()

    def crawl_requirements(self, lvl_exit=2):

        queue = q.LifoQueue()
        root = Quest(link=QUEST_URL.replace("?", str(self.quest_id)))
        queue.put((0, root))

        while not queue.empty():
            level, data = queue.get()
            response = requests.get(data.link)
            if response.status_code != 200:
                print(response.text)
                continue
            txt = ""
            if isinstance(data, Quest):
                self.quest_parser.fill_quest(data, response.text)
                txt = "Crawling Quest: " + data.name
                for requirement in data.requirements_list:
                    if requirement.quantity_data != "Provided":
                        queue.put((level + 1, requirement))
            elif isinstance(data, Item):
                self.item_parser.fill_item(data, response.text)
                txt = "Crawling Item: " + data.name + " - " + str(data.id)
                for quest in data.reward_from_quest_list:
                    queue.put((level + 1, quest))
            if txt != "":
                print(txt.rjust(len(txt) + level, '\t'))
            if 0 < lvl_exit == level:
                continue
        return root
