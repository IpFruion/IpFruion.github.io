from html.parser import HTMLParser

import requests

WOWHEAD_GEAR_SLOT_NAMES = [
    "Head", "Neck", "Shoulders", "Back", "Chest", "Wrists",
    "Legs", "Hands", "Waist", "Feet", "Ring", "Trinkets",
    "Main Hand", "Off-Hand", "Ranged"
]


class GuideParser(HTMLParser):

    def __init__(self):
        super().__init__()
        self.i = 0
        self.slot_index = None
        self.category = None
        self.cur_id = None
        self.is_exit = False
        self.bis_list = []
        for _ in WOWHEAD_GEAR_SLOT_NAMES:
            self.bis_list.append({})

    def handle_startendtag(self, tag, attrs):
        if tag == "br" and self.i != 2:
            self.i += 1

    def handle_data(self, data):
        if self.i == 2:
            if data in WOWHEAD_GEAR_SLOT_NAMES:
                self.slot_index = WOWHEAD_GEAR_SLOT_NAMES.index(data)
            if data == "Ranged":
                self.is_exit = True
        if self.slot_index is not None and self.category is None:
            if "Best" in data:
                self.category = "Best"
            if "Optional" in data:
                self.category = "Optional"
        if self.cur_id is not None:
            if self.category not in self.bis_list[self.slot_index]:
                self.bis_list[self.slot_index][self.category] = []
            self.bis_list[self.slot_index][self.category].append((data, self.cur_id))
            self.category = None
            self.cur_id = None

    def handle_starttag(self, tag, attrs):
        if self.category is not None and tag == 'a':
            href = attrs[0][1]
            id = int(href.split("=")[1])
            self.cur_id = id

    def handle_endtag(self, tag):
        if self.slot_index is not None and tag == "table":
            self.slot_index = None
            if self.is_exit:
                raise StopIteration("Done with Parsing")


class ItemNameParser(HTMLParser):

    def __init__(self):
        super().__init__()
        self.is_in_title = False
        self.name = None

    def handle_starttag(self, tag, attrs):
        if tag == "title":
            self.is_in_title = True

    def handle_data(self, data):
        if self.is_in_title:
            self.name = data.split("-")[0]

    def handle_endtag(self, tag):
        if tag == "title":
            raise StopIteration("Done with Parsing")


def get_bis_list(bis_guide):
    result = requests.get("https://classic.wowhead.com/guides/" + bis_guide)
    if result.status_code != 200:
        return None
    parser = GuideParser()
    try:
        parser.feed(result.text)
    except:
        pass
    return parser.bis_list


def get_name_of_item(item_id):
    result = requests.get("https://classic.wowhead.com/item=" + str(item_id) + "/")
    if result.status_code != 200:
        return None
    parser = ItemNameParser()
    try:
        parser.feed(result.text)
    except:
        pass
    return parser.name
