
class Debuff(object):

    def __init__(self, name, expiration):
        self.name = name
        self.expiration = expiration
