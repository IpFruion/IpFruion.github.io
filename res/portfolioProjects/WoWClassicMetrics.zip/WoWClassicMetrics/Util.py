import os
import platform


class Node(object):
    def __init__(self, value, parent=None):
        self.value = value
        self.parent = parent
        self.children = []

    def append_child(self, node):
        self.children.append(node)


def traverse_construct(construct_str):
    lvl = 0
    index = -1
    in_qoute = False
    for i, c in enumerate(construct_str):
        if c == '"':
            in_qoute = not in_qoute
        if in_qoute:
            continue
        if c == '[' or c == '{' or c == '(':
            lvl += 1
        elif c == ']' or c == '}' or c == ')':
            lvl -= 1
            if lvl == 0:
                index = i
                break
    return construct_str[:index+1]


class DataObject(object):

    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            self.__dict__[key] = value

    def __getattr__(self, item):
        if item.endswith("list"):
            self.__dict__[item] = []
            return self.__dict__[item]
        if item.endswith("dict"):
            self.__dict__[item] = {}
            return self.__dict__[item]
        return None

    def __getstate__(self):
        return self.__dict__

    def __setstate__(self, d):
        self.__dict__.update(d)


class FlagList(object):
    def __init__(self, bool_identifier=None):
        self.__dict__["flag_list"] = {}
        self.__dict__["bool_identifier"] = bool_identifier

    def __getattr__(self, item):
        if item not in self.flag_list:
            if self.bool_identifier is not None and item.startswith(self.bool_identifier):
                return False
            return None
        return self.flag_list[item]

    def __setattr__(self, key, value):
        if key in self.__dict__:
            self.__dict__[key] = value
        self.flag_list[key] = value

    def reset(self):
        self.flag_list = {}


def get_creation_date(file):
    if platform.system() == "Windows":
        return os.path.getctime(file)
    else:
        return os.stat(file).st_birthtime
