import logging
import pickle
import sys
from datetime import datetime
from queue import LifoQueue

import requests

from WoWClassicMetrics import GuildStats
from WoWHeadCrawler import QuestCrawler, ItemParser, Item, ITEM_URL, parse_related_tab, Npc


def print_gear_analysis(gear_analysis):
    for name, analysis in gear_analysis.items():
        print(name)
        score = 0
        for slot, recommendation in analysis.items():
            print("\t" + slot)
            print("\t\tCurrent: " + recommendation["current"][0])
            if "missing_bis" in recommendation:
                print('\t\t', end='')
                print("BiS: " + recommendation["missing_bis"][0])
            if "optional" in recommendation:
                print('\t\t', end='')
                print("Optional")
                for item in recommendation["optional"]:
                    print("\t\t\t" + item[0])

            score += recommendation["value"]
        print("Score: " + str(score))


def get_score_list(gear_analysis):
    score_list = []
    for name, analysis in gear_analysis.items():
        score = 0
        for slot, recommendation in analysis.items():
            score += recommendation["value"]
        score_list.append((name, score))
    return sorted(score_list, key=lambda x: x[1], reverse=True)


def disorder_reports_after(report):
    return datetime.fromtimestamp(report["start"] / 1000) > datetime.strptime("2019-10-23", '%Y-%m-%d')


champions_battlegear = 8573
champions_battle = 8573



def compare_buff_lists(prev, cur, maxlimit):
    change_list = []
    for i in range(len(prev)):
        found = False
        for j in range(len(cur)):
            if prev[i] == cur[j]:
                found = True
                if i != j:
                    change_list.append({"type": "INDEX_CHANGE", "debuff": cur[j], "slot": j})
        if not found:
            # TEST IF PUSHOFF BY MAX LIMIT or by expiration time limit of prev[i]. Could start timers?
            if len(cur_list) == maxlimit:
                change_list.append({"type": "PUSHOFF", "debuff": prev[i]})
            else:
                change_list.append({"type": "EXPIRE", "debuff": prev[i]})

    for i in range(len(cur)):
        change_list.append({"type": "ADD", "debuff": cur[i]})

    return change_list



# Ok so I need to check if debuff has
# 1) Fallen off by either expiring or being pushed off or just somehow removed or dispelled.
# PUSHOFF only occurs when a debuff is added at the same time a buff is added. or beyond max limit.
# 2) Which debuffs are added
# 3) Debuff index change

# Check number of debuffs.
# if 16 then the next debuff added is going to push off
# so now any add to debuff list now knocks off something

prev_list = [1, 2, 3, 4]
cur_list = [2, 4]


l = compare_buff_lists(prev_list, cur_list, 4)
for i in l:
    print(i)


# s = '''{ template: 'guide', id: 'guides', name: LANG.tab_guides, tabs: 'tabsRelated', parent: 'lkljbjkb574', data: [{"id":7879,"title":"Important Open-World Items for Classic WoW PvP","patch":11201,"category":35,"categoryNames":["PvP"],"categoryPath":"pvp","keywords":null,"description":"Overview of important items for Classic PvP which come from open-world content, such as reputation, quests, rare mobs, or events.","author":"ImAlive","when":"2019-01-26 21:03:43","rating":4.43491,"nvotes":11,"status":3,"sticky":false,"flags":0,"spec":0,"comments":2,"authorroles":256,"url":"\/guides\/important-world-items-for-classic-pvp","image":"https:\/\/wow.zamimg.com\/uploads\/guide\/seo\/7879.jpg?1559887197","featured":1},{"id":8013,"title":"Classic WoW First Aid Profession Guide & Leveling 1-300","patch":11300,"category":29,"categoryNames":["Professions"],"categoryPath":"professions","keywords":"first aid, profession, wow classic, classic wow, vanilla, gathering, best professions, PvP professions, PvE professions, first aid trainers, first aid quests, leveling first aid, linen bandage, heavy linen bandage, anti-venom, wool bandage, heavy wool bandage, strong anti-venom, silk bandage, heavy silk bandage, mageweave bandage, heavy mageweave bandage, runecloth bandage, heavy runecloth bandage, powerful anti-venom, triage quest, triage, ahn'qiraj war effort, ","description":"Overview of the First Aid profession in Classic WoW, including quickly leveling First Aid from 1-300, the Triage quest, list of all bandages, and trainer locations.","author":"Ragorism","when":"2019-03-14 15:05:08","rating":4.56665,"nvotes":39,"status":3,"sticky":false,"flags":7,"spec":0,"comments":17,"authorroles":260,"url":"\/guides\/first-aid-classic-wow-1-300","image":"https:\/\/wow.zamimg.com\/uploads\/guide\/seo\/8013.jpg?1554937127","featured":1},{"id":8226,"title":"Comprehensive Classic WoW Consumables List","patch":11304,"category":36,"categoryNames":["Mechanics"],"categoryPath":"mechanics","keywords":"Classic wow consumables list\r\nwarrior raid consumables\r\nmage raid consumables\r\nwarlock raid consumables\r\nrogue raid consumables\r\nhunter raid consumables\r\ndruid raid consumables\r\nshaman raid consumables\r\npriest raid consumables\r\npaladin raid consumables\r\nclassic wow raid consumables","description":"A full list of Classic WoW Consumables for every situation. Find out what consumes you need to maximize your classes' potential!","author":"TheKrugLife","when":"2019-05-08 05:35:48","rating":4.67565,"nvotes":26,"status":3,"sticky":false,"flags":2,"spec":0,"comments":14,"authorroles":260,"url":"\/guides\/classic-wow-consumables-list-for-each-class","image":"https:\/\/wow.zamimg.com\/uploads\/guide\/seo\/8226.jpg?1557874466","featured":1},{"id":8901,"title":"Argent Dawn Reputation Guide","patch":11304,"category":32,"categoryNames":["Reputation"],"categoryPath":"reputation","keywords":"classic, reputations, argent dawn, order of the silver hand, rep, reps, plaguelands, western plaguelands, eastern plaguelands","description":"Everything there is to know about the Argent Dawn, the neutral organization that protects Azeroth against many threats. Includes the Quartermaster's location, how to gain reputation, and rewards.","author":"Neryssa","when":"2019-08-21 10:36:18","rating":4.25894,"nvotes":18,"status":3,"sticky":false,"flags":0,"spec":0,"comments":6,"authorroles":272,"url":"\/guides\/argent-dawn-reputation","image":"https:\/\/wow.zamimg.com\/uploads\/guide\/seo\/8901.jpg?1566500952","featured":1}], }'''
#
# id, data = parse_related_tab(s)

# parser = ItemParser()
# # item = Item(id=20802)
# item = Item(id=8545)
# response = requests.get(ITEM_URL.replace("?", str(item.id)))
# parser.fill_item(item, response.text)
# print(item.reward_from_quest_list)

# crawler = QuestCrawler(8573)
# root = crawler.crawl_requirements(lvl_exit=1)
# with open("wowclassicfiles/quest_8573_reqs.txt", "wb+") as f:
#     pickle.dump(root, f)

# TODO Item Sum on stuff for quest
# with open("wowclassicfiles/quest_8573_reqs.txt", "rb") as f:
#     quest = pickle.load(f)
#     slay_requirements = {}
#     supplies_requirements = {}
#     for requirement in quest.requirements_list:
#         if isinstance(requirement, Item):
#             if requirement.quantity_data is None:
#                 requirement.quantity_data = 1
#             slay_requirements[requirement.name] = {}
#             supplies_requirements[requirement.name] = {}
#             for q in requirement.reward_from_quest_list:
#                 for req in q.requirements_list:
#                     if isinstance(req, Npc):
#                         slay_requirements[requirement.name][req.name] = requirement.quantity_data * req.quantity_data
#                     elif isinstance(req, Item) and req.quantity_data != "Provided":
#                         supplies_requirements[requirement.name][req.name] = requirement.quantity_data * req.quantity_data
#             if len(slay_requirements[requirement.name].keys()) == 0:
#                 del slay_requirements[requirement.name]
#             if len(supplies_requirements[requirement.name].keys()) == 0:
#                 del supplies_requirements[requirement.name]
#
#     for item, amount in supplies_requirements["Cenarion Logistics Badge"].items():
#         print(item, amount)
# guild = GuildStats(sys.argv[1], "US", "Rattlegore", "Disorder", db_location="wowclassicfiles/",
#                    report_filter=disorder_reports_after, log_lvl=logging.DEBUG)


# boss_attendance = guild.get_member_boss_attendance(member_filter=lambda name, member: member["boss_fights_fought"] > 50)

# for item in boss_attendance[:40]:
#     print("{0:s} - {1:05.2f}%".format(item[0], item[1] * 100))

# missed = guild.get_missed_boss_fights("Actrise", report_filter=disorder_reports_after)
# for m in missed:
#     boss_name = guild.zones[m["zone"]]["encounters"][m["boss_id"]]["name"]
#     print("{0} - {1} - {2}".format(m["report_id"], boss_name, m["fight_datetime"]))


# for fight in guild.__get_data__('''SELECT * FROM report_friendlies_fights WHERE report_id=?''', ("4pqa2zCVgxc1XZdQ", )):
#     report_id = fight["report_id"]
#     friend_id = fight["friend_id"]
#     if friend_id in guild.reports[report_id]["players"]:
#         if guild.reports[report_id]["players"][friend_id]["name"] == "Rottydotty":
#             print(fight["fight_id"])

# for friendly in guild.__get_data__('''SELECT * FROM report_friendlies WHERE report_id=? AND name=?''', ("4pqa2zCVgxc1XZdQ", "Rottydotty")):
#     print(friendly)

# mage_bis_list = get_bis_list("mage-dps-gear-bis-classic-wow")
#
# analysis = guild.bis_analysis(mage_bis_list, "Mage")
# for score in get_score_list(analysis):
#     print(score[0], score[1])

# os.remove("wowclassicfiles/US_Rattlegore_Disorder.db")
# sorted_reports = sorted(guild.reports.values(), key=lambda report: report["start"], reverse=True)
#
# print(datetime.datetime.fromtimestamp(sorted_reports[0]["start"] / 1000))

# bis_list = get_bis_list("warlock-dps-gear-bis-classic-wow")

# print_latest_gear(guild, "Kazzad")

# missing = check_bis(guild, bis_list, "Kazzad")
#
# for person, pieces in missing.items():
#     print(person)
#     for piece in pieces:
#         print("\t" + get_name_of_item(piece))


# print(guild.members["Actrise"])
# attendance = guild.boss_fight_attendance()[:40]
# for i in attendance:
#     print(i[0], end=' - ')
#     print('{:05.2f}'.format(i[1] * 100), end=', ')
# print()
