import datetime
import logging
import math
import os
import sqlite3
import time
from concurrent.futures._base import as_completed
from concurrent.futures.thread import ThreadPoolExecutor
from queue import Queue

import requests

from WoWHeadParsing import WOWHEAD_GEAR_SLOT_NAMES


class ClassicLogsApi(object):

    def __init__(self, api_key):
        self.loc = "https://classic.warcraftlogs.com/v1"
        self.api_key = api_key

    def request_json(self, location, **params):
        params["api_key"] = self.api_key
        r = requests.get(self.loc + location, params=params)
        if r.status_code == 200:
            return r.json()
        return None

    def parses(self, serv_region, serv_name, char_name, **params):
        return self.request_json("/parses/character/" + char_name + "/" + serv_name + "/" + serv_region, **params)

    def guild_reports(self, serv_region, serv_name, guild_name, **params):
        return self.request_json("/reports/guild/" + guild_name + "/" + serv_name + "/" + serv_region, **params)

    # ['fights', 'completeRaids', 'lang', 'friendlies', 'enemies', 'friendlyPets', 'enemyPets', 'phases', 'logVersion', 'gameVersion', 'title', 'owner', 'start', 'end', 'zone', 'exportedCharacters']
    def fights_report(self, report_id, **params):
        return self.request_json("/report/fights/" + report_id, **params)

    def events_report(self, report_id, view, **params):
        return self.request_json("/report/events/" + view + "/" + report_id, **params)

    def tables_report(self, report_id, view, **params):
        return self.request_json("/report/tables/" + view + "/" + report_id, **params)

    def zones(self):
        return self.request_json("/zones")


LOGS_GEAR_SLOT_NAMES = [
    "Head", "Neck", "Shoulders", "Shirt", "Chest", "Waist", "Legs",
    "Feet", "Wrists", "Hands", "Ring", "Ring", "Trinkets", "Trinkets",
    "Back", "Main Hand", "Off-Hand", "Ranged"
]


# 1000 MC 1001 Ony 1002 BWL 1003 ZG

class GuildStats(object):

    def __init__(self, api_key, server_region, server_name, guild_name, report_filter=None,
                 db_location="", refresh_time=datetime.timedelta(days=3), log_lvl=logging.WARNING):
        self.reports = None
        self.members = None
        self.db_file_name = db_location + server_region + "_" + server_name + "_" + guild_name + ".db"
        self.api_key = api_key
        self.server_region = server_region
        self.server_name = server_name
        self.guild_name = guild_name

        self.logger = logging.getLogger("DisorderGuild")
        self.logger.setLevel(log_lvl)
        ch = logging.StreamHandler()
        ch.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)

        db_exists = True
        if not os.path.exists(self.db_file_name):
            self.logger.info("Database File doesn't exist Creating")
            db_exists = False
        self.db_conn = sqlite3.connect(self.db_file_name)

        if db_exists:
            last_modified = os.path.getmtime(self.db_file_name)
            diff = datetime.datetime.now() - datetime.datetime.fromtimestamp(last_modified)

            if diff > refresh_time:
                self.logger.info("Database is old updating")
                self.logger.info("Dropping tables...")
                self.__drop_refresh_tables__()
                self.logger.info("Updating reports and creating tables")
                self.__update_db__(start=int(last_modified * 1000))
            else:
                self.logger.info("Database still up to date. Time remaining: " + str(refresh_time - diff))
                self.__update_db__()
        else:
            self.__update_db__()

        self.zones = self.__load_zone_data__()
        if self.reports is None:
            self.reports = self.__load_reports__()
        self.parses = self.__load_parses__()

        self.fights_to_zones = {}
        for z_id, zone in self.zones.items():
            for e_id in zone["encounters"].keys():
                self.fights_to_zones[e_id] = z_id

        self.members = self.__create_members__(report_filter)

    def __create_members__(self, report_filter):
        members = {}
        # Parse initial members with their joined datetime and their last active datetime
        for report in self.reports.values():
            if report_filter is not None and not report_filter(report):
                continue
            for possible_member in report["players"].values():
                name = possible_member["name"]
                if name not in members:
                    members[name] = {}
                    members[name]["joined"] = math.inf
                    members[name]["type"] = possible_member["type"]
                    members[name]["last_active"] = 0
                    members[name]["bosses_since_joined"] = 0
                    members[name]["boss_fights_fought"] = 0
                    members[name]["percentile_avg"] = 0
                    members[name]["percentile_max"] = 0
                report_start_time = report["start"]
                for player_fight_id in possible_member["fights"]:
                    fight = report["fights"][player_fight_id]
                    if report_start_time + fight["start_time"] < members[name]["joined"]:
                        members[name]["joined"] = report_start_time + fight["start_time"]
                    if report_start_time + fight["end_time"] > members[name]["last_active"]:
                        members[name]["last_active"] = report_start_time + fight["end_time"]
                    if fight["boss_id"] > 0:
                        zone = self.fights_to_zones[fight["boss_id"]]
                        if zone == 1000 or zone == 1002:
                            members[name]["boss_fights_fought"] += 1

        # Parse the parses table for gear for each member
        for name, parses in self.parses.items():
            latest_gear = None
            latest_parse_time = 0
            if name not in members:
                continue
            total_encounters = 0
            for report in parses.values():
                for fight in report.values():
                    total_encounters += 1
                    members[name]["percentile_avg"] += fight["percentile"]
                    if members[name]["percentile_max"] < fight["percentile"]:
                        members[name]["percentile_max"] = fight["percentile"]
                    if latest_gear is None:
                        latest_gear = []
                        for gear_piece in fight["gear"]:
                            latest_gear.append(
                                {"name": gear_piece["name"], "id": gear_piece["id"], "icon": gear_piece["icon"],
                                 "quality": gear_piece["quality"]})
                        latest_gear = fight["gear"]
                        continue
                    if latest_parse_time < fight["start_time"]:
                        for i in range(len(fight["gear"])):
                            if fight["gear"][i]["id"] is not None:
                                gear_piece = fight["gear"][i]
                                latest_gear[i] = {"name": gear_piece["name"], "id": gear_piece["id"],
                                                  "icon": gear_piece["icon"],
                                                  "quality": gear_piece["quality"]}
                        latest_parse_time = fight["start_time"]
            print(total_encounters)
            members[name]["percentile_avg"] /= total_encounters
            members[name]["latest_gear"] = latest_gear

        # Setup bosses killed

        for name, member in members.items():
            for report in self.reports.values():
                if report_filter is not None and not report_filter(report):
                    continue
                for fight in report["fights"].values():
                    if fight["boss_id"] > 0 and member["joined"] <= report["start"] + fight["start_time"]:
                        zone = self.fights_to_zones[fight["boss_id"]]
                        if zone == 1000 or zone == 1002:
                            member["bosses_since_joined"] += 1
        return members

    def __table_exists__(self, table_name):
        cur = self.db_conn.cursor()
        does_exist = False
        for _ in cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,)):
            does_exist = True
        return does_exist

    @staticmethod
    def __row_to_dict__(row_description, row):
        row_dict = {}
        names = list(map(lambda x: x[0], row_description))
        i = 0
        for name in names:
            row_dict[name] = row[i]
            i += 1
        return row_dict

    def __get_data__(self, sql_cmd, params=None):
        cur = self.db_conn.cursor()
        if params is None:
            cur_item = cur.execute(sql_cmd)
        else:
            cur_item = cur.execute(sql_cmd, params)
        item = cur_item.fetchone()
        while item is not None:
            item = self.__row_to_dict__(cur.description, item)
            yield item
            item = cur_item.fetchone()

    def __create_zones_table__(self, api):
        cur = self.db_conn.cursor()
        cur.execute('''CREATE TABLE zones (id int, name text, frozen int)''')
        cur.execute('''CREATE TABLE zone_encounters (zone_id, id int, name text)''')
        for zone in api.zones():
            cur.execute('''INSERT INTO zones VALUES (?, ?, ?)''', (zone["id"], zone["name"], int(zone["frozen"])))
            for encounter in zone["encounters"]:
                cur.execute('''INSERT INTO zone_encounters VALUES (?, ?, ?)''',
                            (zone["id"], encounter["id"], encounter["name"]))

    def __create_reports_table__(self, api, max_workers, reset_seconds, start):
        cur = self.db_conn.cursor()
        if not self.__table_exists__("reports"):
            cur.execute('''CREATE TABLE reports
                   (id text, title text, owner text, start UNSIGNED BIG INT, end UNSIGNED BIG INT, zone INT)''')

        reports = api.guild_reports(self.server_region, self.server_name, self.guild_name, start=start)
        for report in reports:
            cur.execute('''INSERT INTO reports VALUES (?, ?, ?, ?, ?, ?)''',
                        (report["id"], report["title"], report["owner"], report["start"],
                         report["end"], report["zone"]))

        cur.execute('''CREATE TABLE report_fights 
               (report_id text, id int, name text, start_time UNSIGNED BIG INT, end_time UNSIGNED BIG INT, boss_id int, kill int)''')

        cur.execute('''CREATE TABLE report_friendlies 
                       (report_id text, id int, name text, guid int, type text)''')

        cur.execute('''CREATE TABLE report_friendlies_fights 
                               (report_id text, friend_id int, fight_id)''')

        cur.execute('''CREATE TABLE report_exported_chars
                                       (report_id text, id UNSIGNED BIG INT, name text, server text, region text)''')

        process_queue = Queue()

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            for report in reports:
                process_queue.put(report["id"])
            num_processed = 0
            while not process_queue.empty():
                futures = {}
                while not process_queue.empty():
                    report_id = process_queue.get()
                    futures[executor.submit(api.fights_report, report_id)] = report_id
                for future in as_completed(futures):
                    fight_data = future.result()
                    report_id = futures[future]
                    if fight_data is None:
                        process_queue.put(report_id)
                        continue
                    num_processed += 1
                    self.logger.debug(
                        "Loading Fight Data: " + '{:05.2f}'.format(num_processed / len(reports) * 100) + "%")

                    for fight in fight_data["fights"]:
                        if "kill" in fight:
                            kill = fight["kill"]
                        else:
                            kill = True
                        cur.execute('''INSERT INTO report_fights VALUES (?, ?, ?, ?, ?, ?, ?)''',
                                    (report_id, fight["id"], fight["name"], fight["start_time"], fight["end_time"],
                                     fight["boss"], int(kill)))

                    # TODO: Add enemies table?
                    for friend in fight_data["friendlies"]:
                        cur.execute('''INSERT INTO report_friendlies VALUES (?, ?, ?, ?, ?)''',
                                    (report_id, friend["id"], friend["name"], friend["guid"], friend["type"]))
                        for fight in friend["fights"]:
                            cur.execute('''INSERT INTO report_friendlies_fights VALUES (?, ?, ?)''',
                                        (report_id, friend["id"], fight["id"]))

                    for character in fight_data["exportedCharacters"]:
                        cur.execute('''INSERT INTO report_exported_chars VALUES (?, ?, ?, ?, ?)''',
                                    (report_id, character["id"], character["name"], character["server"],
                                     character["region"]))
                if not process_queue.empty():
                    self.logger.debug("Waiting on reset Timer for " + str(reset_seconds) + " seconds")
                    time.sleep(reset_seconds)

    def __create_parses_table__(self, api, max_workers, reset_seconds):
        cur = self.db_conn.cursor()
        cur.execute('''CREATE TABLE parses_encounters
                        (report_id text, encounter_id int, fight_id int, character_id UNSIGNED BIG INT,
                        character_name text, class text, spec text, encounter_name text, 
                        start_time UNSIGNED BIG INT, duration UNSIGNED BIG INT, percentile double, difficulty int,
                        rank int, out_of int)''')

        cur.execute('''CREATE TABLE parses_gear
                        (character_name text, report_id text, encounter_id int, fight_id int, id int, name text, icon text, quality text)''')
        num_processed = 0
        process_queue = Queue()

        character_names = []
        for report in self.reports.values():
            for possible_member in report["players"].values():
                if possible_member["name"] not in character_names:
                    character_names.append(possible_member["name"])

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            for name in character_names:
                process_queue.put(name)
            while not process_queue.empty():
                futures = {}
                while not process_queue.empty():
                    name = process_queue.get()
                    futures[executor.submit(api.parses, self.server_region, self.server_name, name)] = name

                for future in as_completed(futures):
                    encounters = future.result()
                    name = futures[future]
                    if encounters is None:
                        process_queue.put(name)
                        continue
                    num_processed += 1
                    self.logger.debug(
                        "Loading Encounters: " + '{:05.2f}'.format((num_processed / len(character_names)) * 100) + "%")
                    for encounter in encounters:
                        cur.execute(
                            '''INSERT INTO parses_encounters VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                            (encounter["reportID"], encounter["encounterID"], encounter["fightID"],
                             encounter["characterID"], encounter["characterName"], encounter["class"],
                             encounter["spec"], encounter["encounterName"], encounter["startTime"],
                             encounter["duration"], encounter["percentile"], encounter["difficulty"],
                             encounter["rank"], encounter["outOf"]))
                        for gear in encounter["gear"]:
                            cur.execute('''INSERT INTO parses_gear VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                                        (encounter["characterName"], encounter["reportID"], encounter["encounterID"],
                                         encounter["fightID"], gear["id"], gear["name"], gear["icon"], gear["quality"]))
                if not process_queue.empty():
                    self.logger.debug("Waiting on reset Timer for " + str(reset_seconds) + " seconds")
                    time.sleep(reset_seconds)

    def __load_zone_data__(self):
        zones = {}
        if not self.__table_exists__("zones"):
            self.logger.error("Missing zones Table")
            return None
        for zone in self.__get_data__('''SELECT * FROM zones'''):
            zone["encounters"] = {}
            for zone_encounters in self.__get_data__('''SELECT * FROM zone_encounters WHERE zone_id=?''',
                                                     (zone["id"],)):
                zone["encounters"][zone_encounters["id"]] = {"name": zone_encounters["name"]}
            zones[zone["id"]] = zone
        return zones

    def __load_reports__(self):
        reports = {}

        for report in self.__get_data__('''SELECT * FROM reports'''):
            if report["id"] not in reports:
                reports[report["id"]] = report
                reports[report["id"]]["fights"] = {}
                reports[report["id"]]["players"] = {}

        for fight in self.__get_data__('''SELECT * FROM report_fights'''):
            fight_data = reports[fight["report_id"]]["fights"]
            fight_data[fight["id"]] = fight

        for player in self.__get_data__('''SELECT DISTINCT report_friendlies.name, report_friendlies.report_id, report_friendlies.id, report_friendlies.type FROM report_friendlies
        INNER JOIN report_exported_chars ON report_friendlies.name=report_exported_chars.name'''):
            players = reports[player["report_id"]]["players"]
            players[player["id"]] = player
            players[player["id"]]["fights"] = []

        for player_fight in self.__get_data__('''SELECT * FROM report_friendlies_fights'''):
            report_id = player_fight["report_id"]
            friend_id = player_fight["friend_id"]
            if friend_id in reports[report_id]["players"]:
                reports[report_id]["players"][friend_id]["fights"].append(player_fight["fight_id"])

        return reports

    def __load_parses__(self):
        parses = {}

        for parse in self.__get_data__('''SELECT * FROM parses_encounters'''):
            name = parse["character_name"]
            if name not in parses:
                parses[name] = {}
            if parse["report_id"] not in parses[name]:
                parses[name][parse["report_id"]] = {}

            parses[name][parse["report_id"]][parse["fight_id"]] = parse
            parses[name][parse["report_id"]][parse["fight_id"]]["gear"] = []

        for gear in self.__get_data__('''SELECT * FROM parses_gear'''):
            parses[gear["character_name"]][gear["report_id"]][gear["fight_id"]]["gear"].append(gear)

        return parses

    def __drop_refresh_tables__(self):
        self.db_conn.execute('''DROP TABLE zones''')
        self.db_conn.execute('''DROP TABLE zone_encounters''')
        self.db_conn.execute('''DROP TABLE parses_encounters''')
        self.db_conn.execute('''DROP TABLE parses_gear''')

    def __update_db__(self, start=-1):

        api = ClassicLogsApi(self.api_key)

        if not self.__table_exists__("zones"):
            self.__create_zones_table__(api)

        if not self.__table_exists__("reports"):
            self.__create_reports_table__(api, 5, 120, 0)
        elif start > 0:
            self.__create_reports_table__(api, 5, 120, start)

        if self.reports is None:
            self.reports = self.__load_reports__()

        if not self.__table_exists__("parses_encounters"):
            self.__create_parses_table__(api, 5, 120)

        self.db_conn.commit()

    def bis_analysis(self, bis_list, char_type):
        gear_analysis = {}
        people = []
        for name, member in self.members.items():
            if char_type.lower() == member["type"].lower():
                people.append(name)
        for person in people:
            gear_analysis[person] = {}
            if "latest_gear" not in self.members[person]:
                continue
            gear = self.members[person]["latest_gear"]
            for i in range(len(gear)):
                if LOGS_GEAR_SLOT_NAMES[i] not in WOWHEAD_GEAR_SLOT_NAMES:
                    continue
                slot_loc = WOWHEAD_GEAR_SLOT_NAMES.index(LOGS_GEAR_SLOT_NAMES[i])
                gear_analysis[person][LOGS_GEAR_SLOT_NAMES[i]] = {}
                bis_slot_categories = bis_list[slot_loc]
                gear_analysis[person][LOGS_GEAR_SLOT_NAMES[i]]["value"] = 0
                missing_bis = True
                missing_optional = True
                for category, pieces in bis_slot_categories.items():
                    # TODO: Gear score???? lol for value
                    for piece in pieces:
                        if category == "Best" and gear[i]["id"] == piece[1]:
                            gear_analysis[person][LOGS_GEAR_SLOT_NAMES[i]]["value"] = 100
                            missing_bis = False
                            missing_optional = False

                        elif category == "Optional" and gear[i]["id"] == piece[1]:
                            gear_analysis[person][LOGS_GEAR_SLOT_NAMES[i]]["value"] = 50
                            missing_optional = False
                            break

                if missing_bis:
                    gear_analysis[person][LOGS_GEAR_SLOT_NAMES[i]]["missing_bis"] = bis_slot_categories["Best"]

                if missing_optional:
                    gear_analysis[person][LOGS_GEAR_SLOT_NAMES[i]]["optional"] = []
                    for category, piece in bis_slot_categories.items():
                        if "Optional" not in category:
                            continue
                        gear_analysis[person][LOGS_GEAR_SLOT_NAMES[i]]["optional"].append(piece)

                gear_analysis[person][LOGS_GEAR_SLOT_NAMES[i]]["current"] = (gear[i]["name"], gear[i]["id"])

        return gear_analysis

    def get_member_boss_attendance(self, member_filter=None):
        attendance = []
        for name, member in self.members.items():
            if member_filter is not None and not member_filter(name, member):
                continue
            attendance.append((name, member["boss_fights_fought"] / member["bosses_since_joined"]))

        return sorted(attendance, key=lambda m: m[1], reverse=True)

    def get_missed_boss_fights(self, name, report_filter=None):
        missed = []
        if name not in self.members:
            return None
        for report in self.reports.values():
            if report_filter is not None and not report_filter(report):
                continue
            player_id = None
            for id, player in report["players"].items():
                if player["name"] == name:
                    player_id = id
                    break
            for fight in report["fights"].values():
                if fight["boss_id"] == 0:
                    continue
                zone = self.fights_to_zones[fight["boss_id"]]
                if zone != 1000 and zone != 1002:
                    continue
                if player_id is None or fight["id"] not in report["players"][player_id]["fights"]:
                    missed.append({
                        "report_id": report["id"],
                        "report_datetime": datetime.datetime.fromtimestamp(report["start"] / 1000),
                        "fight_id": fight["id"],
                        "boss_id": fight["boss_id"],
                        "zone": zone,
                        "fight_datetime": datetime.datetime.fromtimestamp(
                            (report["start"] + fight["start_time"]) / 1000),
                        "boss_name": self.zones[zone]["encounters"][fight["boss_id"]]
                    })
        return missed
